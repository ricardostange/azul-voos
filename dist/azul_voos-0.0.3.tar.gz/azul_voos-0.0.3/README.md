# azul-voos
Scrapping de dados de voos da empresa Azul.

## Módulos utilizados
- Selenium
- BeautifulSoup

## Driver utilizado
- Chrome Driver

## Como Utilizar
- Instalar os módulos necessários
- Baixar a versão adequada do Chrome Driver

Exemplo de uso:
```python
pass
```


[Project Code Structure](https://github.com/ricardostange/azul-voos/blob/main/Azul.png?raw=true "Title")
